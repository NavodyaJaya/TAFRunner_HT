using Xunit;
using Xunit.Abstractions;

namespace xUnit
{
    public class XunitTestClass :IClassFixture<XunitTestClass>
    {
        private readonly ITestOutputHelper testOutputHelper;

        public XunitTestClass(ITestOutputHelper testOutputHelper,XunitTestClass xunitTestClass)
        {
            this.testOutputHelper = testOutputHelper;
            this.testOutputHelper.WriteLine("xUnit test precondition output");
        }

        [Fact]
        public void TestMethodOne()
        {
            this.testOutputHelper.WriteLine("xUnit test method one precondition output");
        }

        [Fact]
        public void TestMethodTwo()
        {
            string expected = "hello";
            string actual = "hell";
            this.testOutputHelper.WriteLine("xUnit test failing method");
            Assert.Equal(expected, actual);
            
        }

        [Fact(Skip = "Waiting for the bug to get fixed")]
        public void TestMethodIgnore()
        {
            this.testOutputHelper.WriteLine("xUnit test ignored method");
        }

        [Fact]
        public void TestMethodThree()
        {

            this.testOutputHelper.WriteLine("xUnit test method three precondition output");
        }

        public void Dispose() {
            this.testOutputHelper.WriteLine("xUnit test methods postcondition output");
        }
    }
}