﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TAF_Runner_xUnit
{
    public class XUnitSetupClass
    {
        public XUnitSetupClass()
        {
            int i = 0;
        }

        public void Dispose()
        {

        }
    }
}
