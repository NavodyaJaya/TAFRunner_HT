using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TAF_RunnerMSTest
{
  
    [TestClass]
    public class MSTestClass
    {
        public TestContext TestContext { get; set; }

        [ClassInitialize]
        public void ClassPreConditionMethod(TestContext testContext)
        {

            testContext.WriteLine("MS Test test class, Class Precondition");
        }

        [TestInitialize]
        public void TestPreConditionMethod()
        {
            TestContext.WriteLine("MS Test test class, Test Precondition");
        }

        [TestMethod]
        public void TestMethodOne()
        {
            string expected = "hello";
            string actual = "hello";

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodTwo()
        {
            var expected = 10;
            var actual = 10;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodFail()
        {

            string expected = "hello";
            string actual = "hell";

            Assert.AreEqual(expected, actual);
        }

        [TestCleanup]
        public void TestPostConditionMethod()
        {

            TestContext.WriteLine("MS Test test class, Test Postcondition");
        }

        [Ignore("Waiting for the bug to get fixed")]
        public void TestMethodIgnore()
        {
            TestContext.WriteLine("MSTest test ignored method due to an error");
        }


        [ClassCleanup]
        public void ClassPostConditionMethod()
        {

            TestContext.WriteLine("MS Test test class, Class Postcondition");
        }

        [AssemblyCleanup]
        public void AssemblyCleanup()
        {

            TestContext.WriteLine("MS Test test class, Assembly Cleanup");
        }
    }
}