namespace TAF_Runner
{
    [Parallelizable(ParallelScope.Fixtures)]
    [TestFixture]
    public class NunitTestClass
    {
        [OneTimeSetUp]
        public void ClassPreConditionMethod() {

            TestContext.WriteLine("Nunit test class, Class Precondition");
        }

        [SetUp]
        public void TestPreConditionMethod()
        {
            TestContext.WriteLine("Nunit test class, Test Precondition");
        }

        [Test]
        public void TestMethodOne()
        {
            Assert.Pass("First test method");
        }

        [Test]
        public void TestMethodTwo()
        {
            Assert.Pass("Second test method");
        }

        [Test]
        public void TestMethodFail()
        {


            string expected = "hello";
            string actual = "hell";

            Assert.AreEqual(expected, actual);
        }

        [Ignore("Waiting for the bug to get fixed")]
        public void TestMethodIgnore()
        {
            TestContext.WriteLine("Nunit test ignored method");
        }

        [TearDown]
        public void TestPostConditionMethod()
        {

            TestContext.WriteLine("Nunit test class, Test Postcondition");
        }

        [OneTimeTearDown]
        public void ClassPostConditionMethod()
        {

            TestContext.WriteLine("Nunit test class, Class Postcondition");
        }
    }
}